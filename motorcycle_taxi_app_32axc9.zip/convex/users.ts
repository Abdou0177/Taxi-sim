import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createProfile = mutation({
  args: {
    name: v.string(),
    role: v.union(v.literal("rider"), v.literal("driver")),
    phoneNumber: v.string(),
    vehicleInfo: v.optional(v.object({
      model: v.string(),
      plateNumber: v.string(),
      color: v.string()
    }))
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.insert("profiles", {
      userId,
      name: args.name,
      role: args.role,
      phoneNumber: args.phoneNumber,
      vehicleInfo: args.vehicleInfo,
      isOnline: args.role === "driver" ? false : undefined
    });
  }
});

export const getProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    return await ctx.db
      .query("profiles")
      .withIndex("by_user", q => q.eq("userId", userId))
      .unique();
  }
});
