import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  profiles: defineTable({
    userId: v.id("users"),
    name: v.string(),
    role: v.union(v.literal("rider"), v.literal("driver")),
    phoneNumber: v.string(),
    // For drivers only
    vehicleInfo: v.optional(v.object({
      model: v.string(),
      plateNumber: v.string(),
      color: v.string()
    })),
    isOnline: v.optional(v.boolean()),
    currentLocation: v.optional(v.object({
      lat: v.number(),
      lng: v.number()
    }))
  }).index("by_user", ["userId"]),

  rides: defineTable({
    riderId: v.id("users"),
    driverId: v.optional(v.id("users")),
    status: v.union(
      v.literal("requested"),
      v.literal("accepted"),
      v.literal("started"),
      v.literal("completed"),
      v.literal("cancelled")
    ),
    pickup: v.object({
      lat: v.number(),
      lng: v.number(),
      address: v.string()
    }),
    dropoff: v.object({
      lat: v.number(),
      lng: v.number(),
      address: v.string()
    }),
    price: v.number(),
    requestedAt: v.number(),
    acceptedAt: v.optional(v.number()),
    completedAt: v.optional(v.number())
  })
    .index("by_rider", ["riderId", "status"])
    .index("by_driver", ["driverId", "status"])
    .index("by_status", ["status"])
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
