import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const requestRide = mutation({
  args: {
    pickup: v.object({
      lat: v.number(),
      lng: v.number(),
      address: v.string()
    }),
    dropoff: v.object({
      lat: v.number(),
      lng: v.number(),
      address: v.string()
    }),
    price: v.number()
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.insert("rides", {
      riderId: userId,
      status: "requested",
      pickup: args.pickup,
      dropoff: args.dropoff,
      price: args.price,
      requestedAt: Date.now()
    });
  }
});

export const acceptRide = mutation({
  args: { rideId: v.id("rides") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const ride = await ctx.db.get(args.rideId);
    if (!ride) throw new Error("Ride not found");
    if (ride.status !== "requested") throw new Error("Ride not available");

    await ctx.db.patch(args.rideId, {
      driverId: userId,
      status: "accepted",
      acceptedAt: Date.now()
    });
  }
});

export const updateLocation = mutation({
  args: {
    location: v.object({
      lat: v.number(),
      lng: v.number()
    })
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", q => q.eq("userId", userId))
      .unique();
    
    if (!profile) throw new Error("Profile not found");
    
    await ctx.db.patch(profile._id, {
      currentLocation: args.location
    });
  }
});

export const getNearbyRides = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db
      .query("rides")
      .withIndex("by_status", q => q.eq("status", "requested"))
      .collect();
  }
});

export const getMyRides = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db
      .query("rides")
      .withIndex("by_rider", q => q.eq("riderId", userId))
      .collect();
  }
});
