import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";

export function RiderDashboard() {
  const myRides = useQuery(api.rides.getMyRides) || [];
  const requestRide = useMutation(api.rides.requestRide);
  const [pickup, setPickup] = useState({ lat: 0, lng: 0, address: "" });
  const [dropoff, setDropoff] = useState({ lat: 0, lng: 0, address: "" });
  const [price, setPrice] = useState(0);

  async function handleRequestRide(e: React.FormEvent) {
    e.preventDefault();
    try {
      await requestRide({ pickup, dropoff, price });
      toast.success("Ride requested successfully");
    } catch (error) {
      toast.error("Failed to request ride");
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-4">Request a Ride</h2>
        <form onSubmit={handleRequestRide} className="space-y-4">
          <div>
            <label className="block mb-1">Pickup Address</label>
            <input
              type="text"
              value={pickup.address}
              onChange={e => setPickup(p => ({ ...p, address: e.target.value }))}
              className="w-full p-2 border rounded"
              required
            />
          </div>

          <div>
            <label className="block mb-1">Dropoff Address</label>
            <input
              type="text"
              value={dropoff.address}
              onChange={e => setDropoff(d => ({ ...d, address: e.target.value }))}
              className="w-full p-2 border rounded"
              required
            />
          </div>

          <div>
            <label className="block mb-1">Price (in local currency)</label>
            <input
              type="number"
              value={price}
              onChange={e => setPrice(Number(e.target.value))}
              className="w-full p-2 border rounded"
              required
              min="0"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600"
          >
            Request Ride
          </button>
        </form>
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-4">My Rides</h2>
        <div className="space-y-4">
          {myRides.map(ride => (
            <div key={ride._id} className="border p-4 rounded">
              <div className="font-semibold">Status: {ride.status}</div>
              <div>From: {ride.pickup.address}</div>
              <div>To: {ride.dropoff.address}</div>
              <div>Price: {ride.price}</div>
              <div>Requested: {new Date(ride.requestedAt).toLocaleString()}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
