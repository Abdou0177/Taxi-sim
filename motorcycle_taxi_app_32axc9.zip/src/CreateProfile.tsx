import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";

export function CreateProfile() {
  const createProfile = useMutation(api.users.createProfile);
  const [role, setRole] = useState<"rider" | "driver">("rider");
  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [vehicleInfo, setVehicleInfo] = useState({
    model: "",
    plateNumber: "",
    color: ""
  });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await createProfile({
        name,
        role,
        phoneNumber,
        vehicleInfo: role === "driver" ? vehicleInfo : undefined
      });
      toast.success("Profile created successfully");
    } catch (error) {
      toast.error("Failed to create profile");
    }
  }

  return (
    <div className="max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-4">Create Your Profile</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1">Role</label>
          <select
            value={role}
            onChange={e => setRole(e.target.value as "rider" | "driver")}
            className="w-full p-2 border rounded"
          >
            <option value="rider">Rider</option>
            <option value="driver">Driver</option>
          </select>
        </div>

        <div>
          <label className="block mb-1">Name</label>
          <input
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            className="w-full p-2 border rounded"
            required
          />
        </div>

        <div>
          <label className="block mb-1">Phone Number</label>
          <input
            type="tel"
            value={phoneNumber}
            onChange={e => setPhoneNumber(e.target.value)}
            className="w-full p-2 border rounded"
            required
          />
        </div>

        {role === "driver" && (
          <div className="space-y-4">
            <div>
              <label className="block mb-1">Vehicle Model</label>
              <input
                type="text"
                value={vehicleInfo.model}
                onChange={e => setVehicleInfo(v => ({ ...v, model: e.target.value }))}
                className="w-full p-2 border rounded"
                required
              />
            </div>
            <div>
              <label className="block mb-1">Plate Number</label>
              <input
                type="text"
                value={vehicleInfo.plateNumber}
                onChange={e => setVehicleInfo(v => ({ ...v, plateNumber: e.target.value }))}
                className="w-full p-2 border rounded"
                required
              />
            </div>
            <div>
              <label className="block mb-1">Vehicle Color</label>
              <input
                type="text"
                value={vehicleInfo.color}
                onChange={e => setVehicleInfo(v => ({ ...v, color: e.target.value }))}
                className="w-full p-2 border rounded"
                required
              />
            </div>
          </div>
        )}

        <button
          type="submit"
          className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600"
        >
          Create Profile
        </button>
      </form>
    </div>
  );
}
