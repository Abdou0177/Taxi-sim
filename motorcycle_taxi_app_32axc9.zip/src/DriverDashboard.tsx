import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";

export function DriverDashboard() {
  const nearbyRides = useQuery(api.rides.getNearbyRides) || [];
  const acceptRide = useMutation(api.rides.acceptRide);

  async function handleAcceptRide(rideId: string) {
    try {
      await acceptRide({ rideId });
      toast.success("Ride accepted successfully");
    } catch (error) {
      toast.error("Failed to accept ride");
    }
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Available Rides</h2>
      <div className="space-y-4">
        {nearbyRides.map(ride => (
          <div key={ride._id} className="border p-4 rounded">
            <div>From: {ride.pickup.address}</div>
            <div>To: {ride.dropoff.address}</div>
            <div>Price: {ride.price}</div>
            <button
              onClick={() => handleAcceptRide(ride._id)}
              className="mt-2 bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
            >
              Accept Ride
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
