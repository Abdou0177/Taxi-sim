import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { RiderDashboard } from "./RiderDashboard";
import { DriverDashboard } from "./DriverDashboard";
import { CreateProfile } from "./CreateProfile";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-xl font-semibold accent-text">Motorcycle Taxi</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 p-4">
        <Content />
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const profile = useQuery(api.users.getProfile);

  return (
    <div className="max-w-4xl mx-auto">
      <Unauthenticated>
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-8">Welcome to Motorcycle Taxi</h1>
          <SignInForm />
        </div>
      </Unauthenticated>
      
      <Authenticated>
        {profile === undefined ? (
          <div className="flex justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
          </div>
        ) : profile === null ? (
          <CreateProfile />
        ) : profile.role === "rider" ? (
          <RiderDashboard />
        ) : (
          <DriverDashboard />
        )}
      </Authenticated>
    </div>
  );
}
